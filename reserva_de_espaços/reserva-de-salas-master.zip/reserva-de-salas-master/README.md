#Sistema gratuito feito em PHP/MySQL para reservas para de salas e laboratórios:
Uma reserva é composta por uma data + sala (espaço)  + período (horário) , para um professor ou cliente, com possibilidade de repetições semanais.

#Requisitos do sistema:
- PHP 7.4
- MySQL 5.7
- Apache

#Instalação 
- instalar o servidor web com requisitos solicitados (apache+php+mysql).
- Rodar o arquivo sgreserva.sql para instalação do banco de dados.
- configurar sua conexãono com MySQL no arquivo \view\config.php
- o primeiro usuário padrão para acesso ao sistema sistema é "teste" com a senha "teste"

