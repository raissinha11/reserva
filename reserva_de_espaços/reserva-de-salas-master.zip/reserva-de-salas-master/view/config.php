<?php

$cfg = new stdClass();

// configuração de banco de dados
$cfg->db_host = '127.0.0.1';
$cfg->db_user = 'root';
$cfg->db_senha = '';
$cfg->db_banco = 'sgreserva';
$cfg->db_porta = 3306;

date_default_timezone_set("Brazil/East");

?>