<div class="menu">

<ul>

   <a href="index.php"><li>Home</li></a>
   <a href="sala_list.php"><li>Salas</li></a>
   <a href="periodo_list.php"><li>Períodos</li></a>
   <a href="relatorios.php"><li>Relatorios</li></a>
   <a href="usuario_list.php"> <li>Usuários</li></a>

</ul>

</div>